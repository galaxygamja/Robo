# 먼저 읽기 — Arduino 보드 코드

1. ZIP을 압축 해제한다.
2. `arduino/RoboRobot/RoboRobot.ino`를 Arduino IDE로 연다. 폴더 전체를 함께 보관한다.
3. `docs/ARDUINO_START_HERE_KO.md`를 읽고 ESP32C3 Dev Module / esp32 코어2.0.17 / ArduinoJson6.21.5를 준비한다.
4. `RobotSettings.h`에서 로봇 번호를 고른다:1=햄스터H1,2=비버B1,3=비버B2,4=비버B3(통신H2).
5. `Secrets.example.h`를 `Secrets.h`로 복사하고 실제 Wi-Fi/토큰을 입력한다. 공개하지 않는다.
6. 첫 업로드는 모터/서보 전원 분리 및 두 출력 허가값0 상태로 한다. 이 패키지가 자동으로 실물 시험을 완료해 주는 것은 아니다.

이 ZIP에는 Python 서버를 새로 넣거나 수정하지 않았다. 보드에서 실행하는 코드만 Arduino C/C++로 들어 있다.
서버/영상처리와의 연결은 기존 https://github.com/galaxygamja/Robo 코드를 사용하며 H1 속도 보정은 새로 측정한다.
공개 코드가 바로 안전하게 주행하도록 모든 실물 값이 채워진 것은 아니다. 안내서의 실물 확인 단계를 건너뛰지 않는다.
